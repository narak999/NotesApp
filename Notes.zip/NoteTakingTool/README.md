# NotesApp

Notes Android application made using Java
